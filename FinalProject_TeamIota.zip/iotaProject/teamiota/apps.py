from django.apps import AppConfig


class TeamiotaConfig(AppConfig):
    name = 'teamiota'
